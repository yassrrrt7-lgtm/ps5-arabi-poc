/*
 * PS5 Arabi POC 2: Universal Running-Game Scanner & Selective Language/Font Extractor
 * Target: PS5 Firmware 5.50 (Orbis OS / etaHEN / elfldr) via ps5-payload-sdk
 * Works on ANY mounted PS4 (CUSA*) or PS5 (PPSA*) game — zero hardcoded game paths.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define PFSMNT_DIR      "/mnt/sandbox/pfsmnt"
#define OUT_ROOT        "/data/arabi_poc"
#define MAX_EXTRACT_MB  150ULL
#define MAX_EXTRACT_B   (MAX_EXTRACT_MB * 1024ULL * 1024ULL)
#define MAX_TOTAL_B     (350ULL * 1024ULL * 1024ULL)

typedef struct {
    uint64_t total_files;
    uint64_t total_bytes;
    uint64_t matched_files;
    uint64_t matched_bytes;
    uint64_t extracted_files;
    uint64_t extracted_bytes;
    uint64_t skipped_large;
} ScanStats;

static void to_lower_copy(const char *src, char *dst, size_t max_len) {
    size_t i = 0;
    for (; src[i] && i + 1 < max_len; i++) {
        dst[i] = (char)tolower((unsigned char)src[i]);
    }
    dst[i] = '\0';
}

static int ends_with(const char *str, const char *suffix) {
    size_t slen = strlen(str);
    size_t suflen = strlen(suffix);
    if (suflen > slen) return 0;
    return strcmp(str + slen - suflen, suffix) == 0;
}

static int mkdir_p(const char *path) {
    char tmp[1024];
    snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = strlen(tmp);
    if (len == 0) return -1;
    if (tmp[len - 1] == '/') tmp[len - 1] = '\0';
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    return mkdir(tmp, 0777) == 0 || errno == EEXIST ? 0 : -1;
}

static int is_localization_or_font(const char *rel_path) {
    char low[1024];
    to_lower_copy(rel_path, low, sizeof(low));

    /* Font formats across Unreal, Unity, Godot, UbiArt, Custom */
    if (ends_with(low, ".ttf") || ends_with(low, ".otf") ||
        ends_with(low, ".fnt") || ends_with(low, ".ufont") ||
        ends_with(low, ".bdf")) {
        return 1;
    }

    /* Direct localization & text formats */
    if (ends_with(low, ".locres") || ends_with(low, ".locmeta") ||
        ends_with(low, ".po") || ends_with(low, ".mo") ||
        ends_with(low, ".loc") || ends_with(low, ".lng") ||
        ends_with(low, ".strings") || ends_with(low, ".srt") ||
        ends_with(low, ".sub")) {
        return 1;
    }

    /* Path-keyword + structured/bundle formats (Unity, Unreal, UbiArt, JSON/XML/CSV) */
    int has_loc_hint = (
        strstr(low, "localiz") != NULL ||
        strstr(low, "/loc/") != NULL ||
        strstr(low, "lang") != NULL ||
        strstr(low, "string") != NULL ||
        strstr(low, "text") != NULL ||
        strstr(low, "font") != NULL ||
        strstr(low, "subtitl") != NULL ||
        strstr(low, "dialog") != NULL ||
        strstr(low, "english") != NULL ||
        strstr(low, "_en.") != NULL ||
        strstr(low, "/en/") != NULL
    );

    if (has_loc_hint) {
        if (ends_with(low, ".json") || ends_with(low, ".xml") ||
            ends_with(low, ".csv") || ends_with(low, ".txt") ||
            ends_with(low, ".ini") || ends_with(low, ".bin") ||
            ends_with(low, ".dat") || ends_with(low, ".bundle") ||
            ends_with(low, ".assets") || ends_with(low, ".pak") ||
            ends_with(low, ".ipk") || ends_with(low, ".uasset")) {
            return 1;
        }
    }

    /* Unity core resources/catalog files */
    if (ends_with(low, "resources.assets") || ends_with(low, "catalog.bin") ||
        ends_with(low, "catalog.json")) {
        return 1;
    }

    return 0;
}

static int copy_file(const char *src, const char *dst) {
    char dst_dir[1024];
    snprintf(dst_dir, sizeof(dst_dir), "%s", dst);
    char *slash = strrchr(dst_dir, '/');
    if (slash) {
        *slash = '\0';
        mkdir_p(dst_dir);
    }

    FILE *in = fopen(src, "rb");
    if (!in) return -1;
    FILE *out = fopen(dst, "wb");
    if (!out) {
        fclose(in);
        return -1;
    }

    uint8_t buf[65536];
    size_t n;
    int err = 0;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) {
            err = -1;
            break;
        }
    }
    fclose(in);
    fclose(out);
    return err;
}

static void walk_dir(
    const char *root,
    const char *rel,
    const char *extract_root,
    FILE *report_fp,
    int *first_entry,
    ScanStats *stats
) {
    char full_dir[1024];
    if (rel[0]) {
        snprintf(full_dir, sizeof(full_dir), "%s/%s", root, rel);
    } else {
        snprintf(full_dir, sizeof(full_dir), "%s", root);
    }

    DIR *d = opendir(full_dir);
    if (!d) return;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) continue;

        char child_rel[1024];
        char child_full[1024];
        if (rel[0]) {
            snprintf(child_rel, sizeof(child_rel), "%s/%s", rel, ent->d_name);
        } else {
            snprintf(child_rel, sizeof(child_rel), "%s", ent->d_name);
        }
        snprintf(child_full, sizeof(child_full), "%s/%s", root, child_rel);

        struct stat st;
        if (stat(child_full, &st) != 0) continue;

        if (S_ISDIR(st.st_mode)) {
            walk_dir(root, child_rel, extract_root, report_fp, first_entry, stats);
        } else if (S_ISREG(st.st_mode)) {
            stats->total_files++;
            stats->total_bytes += (uint64_t)st.st_size;

            if (is_localization_or_font(child_rel)) {
                stats->matched_files++;
                stats->matched_bytes += (uint64_t)st.st_size;

                int extracted = 0;
                if ((uint64_t)st.st_size <= MAX_EXTRACT_B &&
                    (stats->extracted_bytes + (uint64_t)st.st_size) <= MAX_TOTAL_B) {
                    char dst_path[1024];
                    snprintf(dst_path, sizeof(dst_path), "%s/%s", extract_root, child_rel);
                    if (copy_file(child_full, dst_path) == 0) {
                        extracted = 1;
                        stats->extracted_files++;
                        stats->extracted_bytes += (uint64_t)st.st_size;
                    }
                } else {
                    stats->skipped_large++;
                }

                fprintf(report_fp, "%s\n    {\"path\": \"%s\", \"size\": %llu, \"extracted\": %s}",
                        (*first_entry) ? "" : ",",
                        child_rel,
                        (unsigned long long)st.st_size,
                        extracted ? "true" : "false");
                *first_entry = 0;
            }
        }
    }
    closedir(d);
}

static int find_mounted_game(char *out_mount, size_t mount_len, char *out_title_id, size_t tid_len) {
    DIR *d = opendir(PFSMNT_DIR);
    if (!d) return -1;

    struct dirent *ent;
    int found = 0;
    while ((ent = readdir(d)) != NULL) {
        if (strncmp(ent->d_name, "CUSA", 4) == 0 || strncmp(ent->d_name, "PPSA", 4) == 0) {
            /* Prefer -app0-patch0-union, fallback to -app0 or -nest */
            if (strstr(ent->d_name, "-app0-patch0-union") != NULL) {
                snprintf(out_mount, mount_len, "%s/%s", PFSMNT_DIR, ent->d_name);
                snprintf(out_title_id, tid_len, "%.9s", ent->d_name);
                found = 1;
                break;
            } else if (!found && strstr(ent->d_name, "-app0") != NULL) {
                snprintf(out_mount, mount_len, "%s/%s", PFSMNT_DIR, ent->d_name);
                snprintf(out_title_id, tid_len, "%.9s", ent->d_name);
                found = 1;
            }
        }
    }
    closedir(d);
    return found ? 0 : -1;
}

int main(void) {
    mkdir_p(OUT_ROOT);

    char mount_path[512] = {0};
    char title_id[32] = {0};

    FILE *log_fp = fopen(OUT_ROOT "/scanner.log", "w");
    if (!log_fp) return 1;

    if (find_mounted_game(mount_path, sizeof(mount_path), title_id, sizeof(title_id)) != 0) {
        fprintf(log_fp, "FAIL: No running PS4 (CUSA*) or PS5 (PPSA*) game found in %s\n", PFSMNT_DIR);
        fprintf(log_fp, "Tip: Launch any game FIRST, keep it running, then send this payload via elfldr.\n");
        fclose(log_fp);
        return 1;
    }

    char extract_dir[512];
    char report_path[512];
    snprintf(extract_dir, sizeof(extract_dir), "%s/extracted/%s", OUT_ROOT, title_id);
    snprintf(report_path, sizeof(report_path), "%s/scan_%s.json", OUT_ROOT, title_id);
    mkdir_p(extract_dir);

    FILE *rfp = fopen(report_path, "w");
    if (!rfp) {
        fprintf(log_fp, "FAIL: Cannot write report %s\n", report_path);
        fclose(log_fp);
        return 1;
    }

    ScanStats stats;
    memset(&stats, 0, sizeof(stats));
    int first_entry = 1;

    fprintf(rfp, "{\n  \"title_id\": \"%s\",\n  \"mount_path\": \"%s\",\n  \"files\": [", title_id, mount_path);
    walk_dir(mount_path, "", extract_dir, rfp, &first_entry, &stats);
    fprintf(rfp, "\n  ],\n");
    fprintf(rfp, "  \"summary\": {\n");
    fprintf(rfp, "    \"total_files\": %llu,\n", (unsigned long long)stats.total_files);
    fprintf(rfp, "    \"total_bytes\": %llu,\n", (unsigned long long)stats.total_bytes);
    fprintf(rfp, "    \"matched_files\": %llu,\n", (unsigned long long)stats.matched_files);
    fprintf(rfp, "    \"matched_bytes\": %llu,\n", (unsigned long long)stats.matched_bytes);
    fprintf(rfp, "    \"extracted_files\": %llu,\n", (unsigned long long)stats.extracted_files);
    fprintf(rfp, "    \"extracted_bytes\": %llu,\n", (unsigned long long)stats.extracted_bytes);
    fprintf(rfp, "    \"skipped_large\": %llu\n", (unsigned long long)stats.skipped_large);
    fprintf(rfp, "  }\n}\n");
    fclose(rfp);

    fprintf(log_fp, "PASS: Scanned %s (%s)\n", title_id, mount_path);
    fprintf(log_fp, "Total game files: %llu (%.2f MB)\n",
            (unsigned long long)stats.total_files, (double)stats.total_bytes / (1024.0 * 1024.0));
    fprintf(log_fp, "Matched loc/font: %llu (%.2f MB)\n",
            (unsigned long long)stats.matched_files, (double)stats.matched_bytes / (1024.0 * 1024.0));
    fprintf(log_fp, "Extracted safely: %llu (%.2f MB)\n",
            (unsigned long long)stats.extracted_files, (double)stats.extracted_bytes / (1024.0 * 1024.0));
    fprintf(log_fp, "Report saved to: %s\n", report_path);
    fclose(log_fp);
    return 0;
}
